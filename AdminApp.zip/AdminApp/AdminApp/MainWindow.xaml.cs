﻿using DocumentFormat.OpenXml.Office2019.Excel.ThreadedComments;
using Grpc.Core;
using Microsoft.Win32;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace AdminApp
{
    public partial class MainWindow : Window
    {
        ProCreditEntities context = new ProCreditEntities();
        CollectionViewSource clientViewSource;
        public MainWindow()
        {
            InitializeComponent();
            clientViewSource = ((CollectionViewSource)(FindResource("clientViewSource")));
            DataContext = this;

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            context.Clients.Load();
            clientViewSource.Source = context.Clients.Local;
        }

        private void searchBox_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            var filtered = context.Clients.Where(x => x.Name.Contains(searchBox.Text) || x.Address.Contains(searchBox.Text)
                        || x.Id.ToString().Contains(searchBox.Text)).ToList();
            clientViewSource.Source = filtered;
        }

        private void export_Click(object sender, RoutedEventArgs e)
        {
            var clientlist = context.Clients.ToList();
            string jsondata = new JavaScriptSerializer().Serialize(clientlist);
            SaveFileDialog exportDialog = new SaveFileDialog();
            exportDialog.Filter = "Data Files (*.json)|*.json";
            exportDialog.DefaultExt = "json";
            exportDialog.AddExtension = true;
          
            if (exportDialog.ShowDialog() == true)
            {
                string newPath = exportDialog.FileName;
                File.WriteAllText(newPath, jsondata); 
                MessageBox.Show("Data has been sucessfully exported to JSON file", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void exportXML_Click(object sender, RoutedEventArgs e)
        {
            var clientlist = context.Clients.ToList();
  
            var xmlSavePath = new XElement("Clients",
            from c in clientlist
            select new XElement("Client",
                               new XElement("Name", c.Name),
                               new XElement("Address", c.Address),
                               new XElement("BirthDate", c.BirthDate)
                           ));


            SaveFileDialog exportDialog = new SaveFileDialog();
            exportDialog.Filter = "Data Files (*.xml)|*.xml";
            exportDialog.DefaultExt = "xml";
            exportDialog.AddExtension = true;

            if (exportDialog.ShowDialog() == true)
            {
                string newPath = exportDialog.FileName;
                xmlSavePath.Save(newPath);
                MessageBox.Show("Data has been sucessfully exported to XML file", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
           
        }
    }
}
