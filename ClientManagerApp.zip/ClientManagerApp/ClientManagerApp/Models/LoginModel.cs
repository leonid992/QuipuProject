﻿
using System.ComponentModel.DataAnnotations;

namespace ClientManagerApp.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage = "Please Enter Email")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }
        [Required(ErrorMessage = "Please Enter Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
