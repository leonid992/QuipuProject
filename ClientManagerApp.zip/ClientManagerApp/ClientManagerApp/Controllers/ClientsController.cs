﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ClientManagerApp.Models;
using System.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.Logging;

namespace ClientManagerApp.Controllers
{
    public class ClientsController : Controller
    {
        private readonly ProCreditContext _context;
        private readonly ILogger _logger;

        public ClientsController(ProCreditContext context, ILogger<ClientsController> logger)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Create()
        {
            if (!checkAuth())
            {
                return RedirectToAction("Login");
            }
            ViewData["Title"] = "Create";
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Address,BirthDate")] Client client)
        {
            if (!checkAuth())
            {
                return RedirectToAction("Login");
            }
            if (ModelState.IsValid)
            {
                try
                {
                    _context.Add(client);
                    await _context.SaveChangesAsync();
                    _logger.LogInformation("Successfuly created new client");
                    return RedirectToAction(nameof(Create));
                }
                catch (Exception ex /* dex */)
                {
                    string error = ex.Message;
                    if (ex.InnerException.Message.Contains("Violation of PRIMARY KEY"))
                    {
                        error = "There is already client with same ID";
                    }
                    _logger.LogInformation(error);
                    ModelState.AddModelError("", error);
                }
            }
            ViewData["Title"] = "Create";
            return View(client);
        }

        public ActionResult Login()
        {
            if (checkAuth())
            {
                return RedirectToAction("Create");
            }
            ViewData["Title"] = "Login";
            return View();
        }
        [HttpPost]
        public ActionResult Login(LoginModel model)
        {
            if (checkAuth())
            {
                return RedirectToAction("Create");
            }
            if (ModelState.IsValid)
            {
                var user = _context.Users.Where(x => x.Email.Equals(model.Email) && x.Password.Equals(model.Password));
                if (user.Count() > 0)
                {
                    HttpContext.Session.SetString("Auth", model.Email);
                    _logger.LogInformation("Successful login");
                    return RedirectToAction("Create", "Clients");
                }
                else
                {
                    ModelState.AddModelError("", "Invalid User Name or Password");
                    return View(model);
                }
            }
            else
            {
                return View(model);
            }
        }

        public ActionResult Logout()
        {
            _logger.LogInformation("Successful logout");
            HttpContext.Session.SetString("Auth", string.Empty);
            return RedirectToAction("Login");
        }
        private bool checkAuth()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("Auth")))
            {
                ViewData["Auth"] = false;
                return false;
            }
            ViewData["Auth"] = true;
            ViewData["Email"] = HttpContext.Session.GetString("Auth");
            return true;
        }
    }
}
