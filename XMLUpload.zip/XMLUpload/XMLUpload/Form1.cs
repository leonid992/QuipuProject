﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;
using Microsoft.Extensions.Logging;
using System.Xml.Schema;
using System.Xml.Linq;

namespace XMLUpload
{
    public partial class Form1 : Form
    {
        private readonly ILogger _logger;
        public Form1(ILogger<Form1> logger)
        {
            _logger = logger;
            InitializeComponent();
        }

        private void browse_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    filePath.Text = openFileDialog.FileName;
                }
            }
        }

        private void import_Click(object sender, EventArgs e)
        {
            msg.Text = "";
            try
            {
                string XMlFile = filePath.Text;
                if (File.Exists(XMlFile))
                {

                    string workingDirectory = Environment.CurrentDirectory;
                    string projectDirectory = Directory.GetParent(workingDirectory).Parent.Parent.FullName;
                    var path = Path.Combine(projectDirectory, "Client.xsd");
                    XmlSchemaSet schema = new XmlSchemaSet();
                    schema.Add("", path);
                    XmlReader rd = XmlReader.Create(XMlFile);
                    XDocument doc = XDocument.Load(rd);
                    doc.Validate(schema, ValidationEventHandler);

                    string xml = File.ReadAllText(XMlFile);
                    string constr = ConfigurationManager.ConnectionStrings["ProCreditDB"].ConnectionString;
                    using (SqlConnection con = new SqlConnection(constr))
                    {
                        using (SqlCommand cmd = new SqlCommand("InsertXML"))
                        {
                            cmd.Connection = con;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@xml", xml);
                            con.Open();
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                    _logger.LogInformation("Successfuly imported");
                    filePath.Text = "";
                    msg.Text = "Successfully imported";
                }
                else
                {
                    _logger.LogInformation("File doesn't exist");
                }
            }
            catch (Exception ex)
            {
                _logger.LogInformation(ex.Message);
            }
        }

        private void ValidationEventHandler(object sender, ValidationEventArgs e)
        {
            XmlSeverityType type = XmlSeverityType.Warning;
            if (Enum.TryParse<XmlSeverityType>("Error", out type))
            {
                if (type == XmlSeverityType.Error) throw new Exception(e.Message);
            }
        }
    }
}
